# main.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import uvicorn
import PyPDF2
import os
import re

# Initialize the FastAPI application
app = FastAPI(title="JobBoard Resume Parser AI")

# Define the data structure we expect from the Node.js backend
class MatchRequest(BaseModel):
    file_path: str
    job_requirements: List[str]

def extract_text_from_pdf(file_path: str) -> str:
    """Helper function to read and extract text from a PDF file."""
    text = ""
    try:
        with open(file_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + " "
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading PDF: {str(e)}")
    
    return text.lower() # Convert to lowercase for easier matching

@app.post("/parse-and-match")
def parse_and_match(request: MatchRequest):
    """
    Receives a file path and a list of required skills.
    Reads the PDF, searches for the skills, and returns a match score.
    """
    
    # 1. Verify the file exists on the system
    if not os.path.exists(request.file_path):
        raise HTTPException(status_code=404, detail=f"File not found: {request.file_path}")

    # 2. Extract text from the PDF
    resume_text = extract_text_from_pdf(request.file_path)
    
    # 3. Find matching skills
    extracted_skills = []
    for req in request.job_requirements:
        skill = req.strip().lower()
        
        # Use regex for exact word boundaries so "c" doesn't match inside "react"
        pattern = r'\b' + re.escape(skill) + r'\b'
        
        if re.search(pattern, resume_text):
            extracted_skills.append(skill)
            
    # 4. Calculate the Match Score (%)
    total_reqs = len(request.job_requirements)
    if total_reqs == 0:
        match_score = 0
    else:
        match_score = int((len(extracted_skills) / total_reqs) * 100)
        
    # 5. Return the response to the Node.js backend
    return {
        "match_score": match_score,
        "extracted_skills": extracted_skills
    }

if __name__ == "__main__":
    # Run the server on port 8000
    uvicorn.run(app, host="0.0.0.0", port=8000)